# 📊 How to Update Game Scores

## Current Status
- **Total Games**: 16 predictions made
- **Correct Predictions**: 0 (no scores uploaded yet)
- **Accuracy**: 0% (waiting for actual game results)

## 🎯 How to Add Game Results

### Method 1: Edit JSON File (Recommended)

1. **Open** `data/week3_predictions.json`
2. **Find** the `"results"` section (currently empty)
3. **Add** game results in this format:

```json
"results": {
  "MIA@BUF": { "home_score": 24, "away_score": 17, "actual_winner": "BUF" },
  "ATL@CAR": { "home_score": 14, "away_score": 21, "actual_winner": "ATL" }
}
```

### Method 2: Edit JavaScript Files

If you prefer to edit the JavaScript directly:

1. **Open** `js/app.js` or `simple.html`
2. **Find** the `results: {}` section
3. **Add** results in the same format

## 📝 Example Format

For each game, add:
```json
"TEAM1@TEAM2": { 
  "home_score": 24, 
  "away_score": 17, 
  "actual_winner": "HOME_TEAM" 
}
```

**Important Notes:**
- `TEAM1` = Away team abbreviation
- `TEAM2` = Home team abbreviation  
- `home_score` = Home team's final score
- `away_score` = Away team's final score
- `actual_winner` = Team abbreviation of the winning team

## 🚀 Deploy Changes

### Option 1: Netlify (if using GitHub)
1. **Push** changes to your GitHub repository
2. **Netlify** will automatically redeploy

### Option 2: Manual Upload
1. **Zip** the updated `blog-site` folder
2. **Drag and drop** to Netlify again
3. **Replace** the existing deployment

### Option 3: Netlify CLI
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod --dir=blog-site
```

## ✅ What Happens After Update

Once you add the actual scores:
- **Home page** will show ✅ CORRECT or ❌ INCORRECT for each game
- **Statistics page** will calculate real accuracy percentage
- **Settled picks table** will show all completed games

## 📋 Current Predictions (Week 3)

| Game | Predicted Winner | Confidence |
|------|------------------|------------|
| MIA @ BUF | BUF | 81.0% |
| ATL @ CAR | ATL | 66.0% |
| GB @ CLE | GB | 80.7% |
| HOU @ JAX | JAX | 69.3% |
| CIN @ MIN | CIN | 64.2% |
| PIT @ NE | NE | 63.2% |
| LA @ PHI | PHI | 53.8% |
| NYJ @ TB | TB | 71.8% |
| IND @ TEN | IND | 89.8% |
| LV @ WAS | LV | 52.5% |
| DEN @ LAC | LAC | 68.8% |
| NO @ SEA | SEA | 51.0% |
| DAL @ CHI | DAL | 78.2% |
| ARI @ SF | ARI | 57.7% |
| KC @ NYG | KC | 50.6% |
| DET @ BAL | BAL | 57.5% |

## 🎯 Next Steps

1. **Wait** for games to be played
2. **Get** the actual final scores
3. **Update** the results section
4. **Deploy** the changes
5. **Check** the statistics page for accuracy

---

**Remember**: The site will only show correct/incorrect results AFTER you manually upload the actual game scores. Until then, it shows 0% accuracy as it should!
